## 𝐒𝐡𝐢𝐧𝐞𝐒𝐩𝐲 | 𝐒𝐤𝐢𝐧 𝐎𝐢𝐥𝐢𝐧𝐞𝐬𝐬 𝐃𝐞𝐭𝐞𝐜𝐭𝐢𝐧𝐠 𝐮𝐬𝐢𝐧𝐠 𝐃𝐞𝐞𝐩 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠

Presenting ShineSpy, our latest mobile app designed to revolutionize your skin care regimen. Using advanced AI technology, ShineSpy uses a training model and TFLite to accurately analyze skin oiliness, seamlessly integrating with Firebase to provide a flawless user experience.

𝐊𝐞𝐲 𝐅𝐞𝐚𝐭𝐮𝐫𝐞𝐬
- 𝐀𝐜𝐜𝐮𝐫𝐚𝐭𝐞 𝐒𝐤𝐢𝐧 𝐀𝐧𝐚𝐥𝐲𝐬𝐢𝐬 : State-of-the-art AI models are used to provide a detailed understanding of your skin's oiliness level.
  
- 𝐏𝐞𝐫𝐬𝐨𝐧𝐚𝐥𝐢𝐳𝐞𝐝 𝐒𝐤𝐢𝐧 𝐂𝐚𝐫𝐞 𝐀𝐫𝐭𝐢𝐜𝐥𝐞𝐬 : Access a wealth of articles tailored to your skin oiliness level to help you stay informed and make the best choices for your skin.
  
- 𝐓𝐚𝐢𝐥𝐨𝐫𝐞𝐝 𝐏𝐫𝐨𝐝𝐮𝐜𝐭 𝐑𝐞𝐜𝐨𝐦𝐦𝐞𝐧𝐝𝐚𝐭𝐢𝐨𝐧𝐬 : Get customized recommendations for skin care products that are perfectly suited to your unique needs based on your skin's oiliness level, ensuring you achieve the best results.
  
- 𝐈𝐧𝐭𝐞𝐫𝐚𝐜𝐭𝐢𝐯𝐞 𝐂𝐡𝐚𝐭𝐛𝐨𝐭 : Engage with our chatbot, equipped with predefined answers to common skincare questions, providing instant support and guidance.

## Demonstration

https://github.com/basuru07/shiny_spy/assets/114737698/81f93e96-bddf-4520-a68c-59f6cdd08ba2

