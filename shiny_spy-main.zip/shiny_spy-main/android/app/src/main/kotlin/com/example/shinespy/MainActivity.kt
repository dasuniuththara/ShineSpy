package com.example.shinespy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
